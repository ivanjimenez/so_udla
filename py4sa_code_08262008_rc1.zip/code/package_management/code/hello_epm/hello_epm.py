#!/usr/bin/env python

import optparse

def main():
    p = optparse.OptionParser()
    p.add_option('--os', '-o', default="*NIX")
    options, arguments = p.parse_args()
    print 'Hello EPM, I like to make packages on %s' % options.os

if __name__ == '__main__':
    main()


