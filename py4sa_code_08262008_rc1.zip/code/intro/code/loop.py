#!/usr/bin/env python

for a in [1, 2]:
    for b in ['a', 'b']:
        print a, b
