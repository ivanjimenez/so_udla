#!/usr/bin/env python
#Python function run 5 times in a for loop

def pyfunc():
    print "Hello function"

for i in range(5):
    pyfunc()

 
