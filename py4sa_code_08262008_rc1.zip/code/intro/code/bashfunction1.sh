#!/usr/bin/env bash
#calling a function 5 times in a for loop

function shfunc()

{
    printf "Hello function\n"
}

for (( i=0 ; i < 5 ; i++))
do
    shfunc
done


