==============  ============  ================
  Server Name    IP Address    Function
==============  ============  ================
card            192.168.1.2   mail server
vinge           192.168.1.4   web server
asimov          192.168.1.8   database server
stephenson      192.168.1.16  file server
gibson          192.168.1.32  print server
==============  ============  ================
